import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Let Express parse JSON bodies
  app.use(express.json());

  // API Route for Free Mode Math Solver
  app.post('/api/math/solve', async (req, res) => {
    try {
      const { problem } = req.body;
      if (!problem) {
        return res.status(400).json({ error: 'Problem is required' });
      }

      if (!process.env.GEMINI_API_KEY) {
        throw new Error('GEMINI_API_KEY environment variable is required');
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `Resuelve el siguiente problema de matemáticas paso a paso. 
        Si el problema no tiene sentido o está incompleto, explica por qué.
        Asegúrate de usar formato Markdown para el texto y bloques de código \`\`\` o formato $ para ecuaciones en LaTeX.
        Problema: ${problem}`,
        config: {
          systemInstruction: 'Eres un tutor de matemáticas amigable. Das explicaciones paso a paso claras y precisas del nivel de secundaria.',
          temperature: 0.2,
        },
      });

      res.json({ solution: response.text });
    } catch (error: any) {
      console.error('Error generating math solution:', error);
      res.status(500).json({ error: 'Failed to solve problem', details: error.message });
    }
  });

  // API route for explaining a mistake in a system of equations
  app.post('/api/math/explain-mistake', async (req, res) => {
    try {
      const { problem, method, userAnswer } = req.body;

      if (!process.env.GEMINI_API_KEY) {
        throw new Error('GEMINI_API_KEY environment variable is required');
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `El estudiante estaba resolviendo el siguiente sistema de ecuaciones por el método de ${method}:
        ${problem}
        
        Su respuesta incorrecta fue: ${userAnswer}
        
        Por favor, explícale amigablemente dónde puede estar su error, y muéstrale paso a paso cómo resolver este sistema usando el método de ${method}. Usa formato Markdown y sintaxis matemática (LaTeX es bienvenido usando el símbolo de dólar o bloques). Mantén la explicación concisa y fácil de entender para un estudiante. No le des un regaño. Empieza con algo animador como "¡No te preocupes! Veamos paso a paso...".`,
        config: {
          temperature: 0.2,
        },
      });

      res.json({ explanation: response.text });
    } catch (error: any) {
      console.error('Error explaining mistake:', error);
      res.status(500).json({ error: 'Failed to explain mistake', details: error.message });
    }
  });

  // API route for getting a step-by-step hint
  app.post('/api/math/hint', async (req, res) => {
    try {
      const { problem } = req.body;

      if (!process.env.GEMINI_API_KEY) {
        throw new Error('GEMINI_API_KEY environment variable is required');
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: `El estudiante está intentando resolver este sistema de ecuaciones:\n${problem}\n\nDale una breve pista amigable (solo 1 o 2 oraciones máximas) de cuál sería el mejor primer paso para resolverlo (Ej: "Intenta despejar la x en la segunda ecuación." o "Suma ambas ecuaciones para eliminar la y."). No le des la respuesta final ni resuelvas todo el problema.`,
        config: { temperature: 0.2 },
      });

      res.json({ hint: response.text });
    } catch (error: any) {
      console.error('Error generating hint:', error);
      res.status(500).json({ error: 'Failed to generate hint', details: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // For Express v4
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
