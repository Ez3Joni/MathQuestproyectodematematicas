import React from 'react';
import { useStore } from '../lib/store';
import { ACHIEVEMENTS } from '../lib/achievements';
import { Award, CheckCircle, ArrowUpCircle, Star, Calendar, Target, Lock } from 'lucide-react';
import { motion } from 'motion/react';

const iconMap: Record<string, React.ReactNode> = {
  Award: <Award className="w-8 h-8" />,
  CheckCircle: <CheckCircle className="w-8 h-8" />,
  ArrowUpCircle: <ArrowUpCircle className="w-8 h-8" />,
  Star: <Star className="w-8 h-8" />,
  Calendar: <Calendar className="w-8 h-8" />,
  Target: <Target className="w-8 h-8" />
};

export function Achievements() {
  const { state } = useStore();
  const unlocked = state.unlockedAchievements;

  return (
    <div className="w-full max-w-3xl mt-4 md:mt-8 flex flex-col items-center">
      <div className="text-center mb-8">
        <h2 className="text-3xl md:text-5xl font-light text-white tracking-tight flex items-center justify-center gap-4">
          Tus <span className="font-bold text-yellow-400">Logros</span>
        </h2>
        <p className="text-slate-400 mt-3 text-lg">
          Has desbloqueado {unlocked.length} de {ACHIEVEMENTS.length} logros
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
        {ACHIEVEMENTS.map(achievement => {
          const isUnlocked = unlocked.includes(achievement.id);

          return (
            <motion.div
              key={achievement.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
              className={`p-6 rounded-3xl border flex items-center gap-4 transition-all ${
                isUnlocked 
                  ? 'bg-slate-800/80 border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.1)] text-white'
                  : 'bg-slate-900/40 border-slate-700/50 text-slate-500 saturate-0 opacity-60'
              }`}
            >
              <div className={`p-3 rounded-2xl border ${
                isUnlocked ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400' : 'bg-slate-800 border-slate-700 text-slate-500'
              }`}>
                {isUnlocked ? (iconMap[achievement.icon] || <Award className="w-8 h-8" />) : <Lock className="w-8 h-8" />}
              </div>
              <div className="flex-1">
                <h4 className={`font-bold text-lg ${isUnlocked ? 'text-white' : 'text-slate-400'}`}>{achievement.title}</h4>
                <p className="text-sm mt-1 leading-tight">{achievement.description}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
