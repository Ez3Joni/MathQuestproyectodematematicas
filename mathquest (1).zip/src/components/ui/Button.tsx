import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { playSound } from '../../lib/audio';

interface ButtonProps extends HTMLMotionProps<"button"> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className = '', variant = 'primary', size = 'md', fullWidth, children, onClick, ...props }, ref) => {
    
    let baseStyles = "inline-flex items-center justify-center font-bold rounded-2xl transition-all focus:outline-none focus:ring-4 focus:ring-opacity-50 active:scale-95 disabled:opacity-50 disabled:pointer-events-none";
    
    const variants = {
      primary: "bg-gradient-to-b from-blue-500 to-blue-600 text-white border-none shadow-[0_4px_0_rgb(29,78,216),0_10px_20px_-10px_rgba(59,130,246,0.5)] active:translate-y-1 active:shadow-none focus:ring-blue-500/50",
      secondary: "bg-gradient-to-b from-green-400 to-green-600 text-white border-none shadow-[0_4px_0_rgb(22,163,74),0_15px_30px_-10px_rgba(34,197,94,0.5)] active:translate-y-1 active:shadow-none focus:ring-green-500/50",
      danger: "bg-gradient-to-b from-rose-500 to-rose-600 text-white border-none shadow-[0_4px_0_rgb(190,18,60),0_10px_20px_-10px_rgba(225,29,72,0.5)] active:translate-y-1 active:shadow-none focus:ring-rose-500/50",
      outline: "bg-slate-800/50 text-slate-300 border-2 border-slate-600 hover:bg-slate-800 hover:text-white hover:border-slate-500 active:translate-y-[2px]",
      ghost: "text-slate-400 hover:text-white hover:bg-slate-800/50 active:bg-slate-800 rounded-xl",
    };

    const sizes = {
      sm: "px-4 py-2 text-sm",
      md: "px-6 py-3 text-base",
      lg: "px-10 py-4 text-xl tracking-wide",
    };

    const classes = `${baseStyles} ${variants[variant]} ${sizes[size]} ${fullWidth ? 'w-full' : ''} ${className}`;

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      playSound('click');
      if (onClick) {
        onClick(e);
      }
    };

    return (
      <motion.button ref={ref} className={classes} whileTap={{ scale: 0.97 }} onClick={handleClick} {...props}>
        {children}
      </motion.button>
    );
  }
);

Button.displayName = 'Button';
