import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useStore } from '../lib/store';
import { Heart, Star, ChevronLeft, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AchievementToasts } from './AchievementToasts';
import { playAmbientMusic } from '../lib/audio';

export function Layout() {
  const { state, user, login, logout, loadingAuth } = useStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  useEffect(() => {
    const handleInteraction = () => {
      playAmbientMusic();
      window.removeEventListener('click', handleInteraction);
    };
    window.addEventListener('click', handleInteraction);
    
    // Attempt to play immediately (might fail if audio context is suspended, but will run on click)
    playAmbientMusic();

    return () => {
      window.removeEventListener('click', handleInteraction);
    };
  }, []);

  const isHome = location.pathname === '/';

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 font-sans flex flex-col relative overflow-x-hidden md:overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none bg-[radial-gradient(circle_at_50%_-20%,rgba(59,130,246,0.15),transparent_60%)] z-0"></div>
      
      <header className="h-20 bg-slate-900/60 backdrop-blur-xl border-b border-slate-700/50 flex items-center px-4 md:px-8 z-30 sticky top-0 shadow-lg">
        <div className="w-full max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            {!isHome && (
              <button 
                onClick={() => navigate('/')} 
                className="p-2 -ml-2 rounded-full hover:bg-slate-800 transition-colors"
                aria-label="Volver al menú"
              >
                <ChevronLeft className="w-6 h-6 text-slate-400 hover:text-white" />
              </button>
            )}
            <h1 className="text-2xl font-black tracking-tight text-white cursor-pointer" onClick={() => navigate('/')}>
              Math<span className="text-cyan-400">Quest</span>
            </h1>
          </div>
          
          <div className="flex items-center gap-4 md:gap-6 font-medium">
            <div className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-slate-800/50 rounded-2xl border border-rose-500/30 shadow-inner" title="Corazones">
              <motion.div
                key={state.hearts}
                initial={{ scale: 1.5 }}
                animate={{ scale: 1 }}
                className="flex items-center gap-1.5 md:gap-2"
              >
                <Heart className="w-5 h-5 md:w-6 md:h-6 fill-rose-500 text-rose-500" />
                <span className="text-slate-200 font-bold text-base md:text-lg">{state.hearts}</span>
              </motion.div>
            </div>
            
            <div className="flex flex-col items-end" title="Puntos">
              <span className="hidden md:block text-[10px] uppercase tracking-widest text-amber-400 font-bold">Puntaje</span>
              <motion.div
                key={state.points}
                initial={{ y: -10, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="flex items-center"
              >
                <span className="text-xl md:text-2xl font-mono font-black tracking-tight text-white">{state.points} <span className="text-xs md:text-sm text-amber-500 font-bold">XP</span></span>
              </motion.div>
            </div>

            <div className="relative border-l border-slate-700/50 pl-4 md:pl-6 ml-2 md:ml-2">
              {!loadingAuth && (
                user ? (
                  <div className="relative">
                    <button 
                      onClick={() => setShowProfileMenu(p => !p)} 
                      className="w-10 h-10 rounded-full border-2 border-cyan-500/50 hover:border-cyan-400 overflow-hidden focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-colors"
                    >
                      {user.photoURL ? (
                        <img src={user.photoURL} alt="User" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full bg-slate-800 flex items-center justify-center">
                          <UserIcon className="w-5 h-5 text-slate-400" />
                        </div>
                      )}
                    </button>
                    <AnimatePresence>
                      {showProfileMenu && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: 10, scale: 0.95 }}
                          className="absolute right-0 mt-3 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl py-2 z-50 focus:outline-none"
                        >
                          <div className="px-4 py-2 border-b border-slate-700/50 mb-2">
                            <p className="text-sm font-medium text-white truncate">{user.displayName || 'Usuario'}</p>
                            <p className="text-xs text-slate-400 truncate mt-0.5">{user.email}</p>
                          </div>
                          <button 
                            onClick={() => { setShowProfileMenu(false); logout(); }}
                            className="w-full text-left px-4 py-2 text-sm text-rose-400 hover:bg-slate-700/50 flex items-center gap-2 transition-colors"
                          >
                            <LogOut className="w-4 h-4" /> Cerrar sesión
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                ) : (
                  <button 
                    onClick={login}
                    className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-4 py-2 rounded-xl text-sm font-medium transition-colors border border-slate-700 hover:border-slate-600"
                  >
                    <LogIn className="w-4 h-4" /> <span className="hidden md:inline">Entrar</span>
                  </button>
                )
              )}
            </div>

          </div>
        </div>
      </header>

      <main className="flex-1 w-full max-w-4xl mx-auto p-4 md:p-8 flex flex-col items-center z-10 custom-scroll flex-grow overflow-y-auto">
        <Outlet />
      </main>
      
      <AchievementToasts />
    </div>
  );
}
