import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from './ui/Button';
import { BlockMath, InlineMath } from 'react-katex';

import { BookOpen } from 'lucide-react';

export function MethodPractice() {
  const { method } = useParams();
  const navigate = useNavigate();

  const isSubstitution = method === 'substitution';

  return (
    <div className="w-full max-w-3xl mt-4 md:mt-8 bg-slate-900/80 backdrop-blur-xl p-6 md:p-10 rounded-[40px] shadow-2xl border border-slate-700/50">
      <div className="flex items-center gap-4 mb-8">
        <div className={`p-4 rounded-3xl ${isSubstitution ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30 shadow-[0_0_20px_rgba(59,130,246,0.3)]' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-[0_0_20px_rgba(16,185,129,0.3)]'}`}>
           <BookOpen className="w-8 h-8" />
        </div>
        <h2 className="text-3xl md:text-4xl font-light text-white tracking-tight">
          Método de <span className={`font-bold ${isSubstitution ? 'text-blue-400' : 'text-emerald-400'}`}>{isSubstitution ? 'Sustitución' : 'Igualación'}</span>
        </h2>
      </div>

      <div className="prose prose-invert prose-lg max-w-none text-slate-300">
        <p className="font-medium text-slate-400 mb-8 border-b border-slate-800 pb-4">
          Aprende paso a paso cómo resolver un sistema de ecuaciones.
        </p>

        {isSubstitution ? (
          <div className="space-y-8">
            <div className="relative bg-slate-800/40 p-8 rounded-3xl border border-slate-700/50 shadow-inner">
               <div className="absolute -top-4 left-8 px-5 py-1.5 bg-blue-600 rounded-full text-xs font-bold text-white shadow-lg tracking-widest uppercase">Problema de ejemplo</div>
               <div className="text-2xl text-center text-white font-mono mt-4">
                 <BlockMath math={"\\begin{cases} 2x + y = 7 \\\\ x - y = 2 \\end{cases}"} />
               </div>
            </div>

            <ol className="space-y-6 list-decimal pl-6 marker:text-blue-500 marker:font-black">
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Despeja una variable:</strong> Toma la segunda ecuación y despeja <InlineMath math="x" />.
                <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-blue-100 shadow-inner"><BlockMath math="x = y + 2" /></div>
              </li>
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Sustituye en la otra ecuación:</strong> Reemplaza el <InlineMath math="x" /> en la primera ecuación.
                <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-blue-100 shadow-inner"><BlockMath math="2(y + 2) + y = 7" /></div>
              </li>
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Resuelve para la variable:</strong> Resuelve la ecuación para <InlineMath math="y" />.
                <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-blue-100 shadow-inner">
                  <BlockMath math="2y + 4 + y = 7" />
                  <BlockMath math="3y = 3" />
                  <BlockMath math="y = 1" />
                </div>
              </li>
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Sustituye de vuelta:</strong> Usa el valor de <InlineMath math="y" /> para encontrar <InlineMath math="x" />.
                <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-blue-100 shadow-inner">
                  <BlockMath math="x = (1) + 2" />
                  <BlockMath math="x = 3" />
                </div>
              </li>
            </ol>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="relative bg-slate-800/40 p-8 rounded-3xl border border-slate-700/50 shadow-inner">
               <div className="absolute -top-4 left-8 px-5 py-1.5 bg-emerald-600 rounded-full text-xs font-bold text-white shadow-lg tracking-widest uppercase">Problema de ejemplo</div>
               <div className="text-2xl text-center text-white font-mono mt-4">
                 <BlockMath math={"\\begin{cases} y = 2x + 1 \\\\ y = x + 3 \\end{cases}"} />
               </div>
            </div>

            <ol className="space-y-6 list-decimal pl-6 marker:text-emerald-500 marker:font-black">
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Despeja la misma variable:</strong> En este ejemplo, la variable <InlineMath math="y" /> ya está despejada en ambas.
              </li>
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Iguala las expresiones:</strong> Igualamos ambas ecuaciones.
                 <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-emerald-100 shadow-inner"><BlockMath math="2x + 1 = x + 3" /></div>
              </li>
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Resuelve para la variable:</strong> Resuelve la nueva ecuación para <InlineMath math="x" />.
                 <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-emerald-100 shadow-inner">
                  <BlockMath math="2x - x = 3 - 1" />
                  <BlockMath math="x = 2" />
                 </div>
              </li>
              <li className="pl-4">
                <strong className="text-white block mb-2 font-bold tracking-wide">Sustituye de vuelta:</strong> Usa el valor de <InlineMath math="x" /> en cualquiera de las ecuaciones originales.
                 <div className="my-4 p-4 bg-slate-900 rounded-2xl border border-slate-800 text-center font-mono text-emerald-100 shadow-inner">
                  <BlockMath math="y = 2(2) + 1" />
                  <BlockMath math="y = 5" />
                 </div>
              </li>
            </ol>
          </div>
        )}
      </div>

      <div className="mt-10 pt-8 border-t border-slate-800">
        <Button size="lg" variant={isSubstitution ? 'primary' : 'secondary'} fullWidth onClick={() => navigate('/play')}>
          ¡Entendido, vamos a jugar!
        </Button>
      </div>
    </div>
  );
}
