import React, { useEffect } from 'react';
import { useStore } from '../lib/store';
import { ACHIEVEMENTS } from '../lib/achievements';
import { motion, AnimatePresence } from 'motion/react';
import { Award, CheckCircle, ArrowUpCircle, Star, Calendar, Target } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Award: <Award className="w-8 h-8 text-yellow-400" />,
  CheckCircle: <CheckCircle className="w-8 h-8 text-emerald-400" />,
  ArrowUpCircle: <ArrowUpCircle className="w-8 h-8 text-blue-400" />,
  Star: <Star className="w-8 h-8 text-amber-400" />,
  Calendar: <Calendar className="w-8 h-8 text-purple-400" />,
  Target: <Target className="w-8 h-8 text-red-400" />
};

export function AchievementToasts() {
  const { recentUnlocks, clearRecentUnlocks } = useStore();

  useEffect(() => {
    if (recentUnlocks.length > 0) {
      const timer = setTimeout(() => {
        clearRecentUnlocks();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [recentUnlocks, clearRecentUnlocks]);

  if (recentUnlocks.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-4">
      <AnimatePresence>
        {recentUnlocks.map(id => {
          const achievement = ACHIEVEMENTS.find(a => a.id === id);
          if (!achievement) return null;
          return (
            <motion.div
              key={id}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 50, scale: 0.9 }}
              className="bg-slate-800/95 backdrop-blur-xl border-2 border-yellow-500/50 p-4 rounded-3xl shadow-[0_0_30px_rgba(234,179,8,0.3)] flex items-center gap-4 min-w-[300px]"
            >
              <div className="p-2 bg-yellow-500/10 rounded-2xl border border-yellow-500/20">
                {iconMap[achievement.icon] || <Award className="w-8 h-8 text-yellow-400" />}
              </div>
              <div className="flex-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-yellow-500 mb-1">¡Logro Desbloqueado!</p>
                <h4 className="text-white font-bold">{achievement.title}</h4>
                <p className="text-slate-400 text-xs font-medium">{achievement.description}</p>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
