import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './ui/Button';
import { useStore } from '../lib/store';
import { Rocket, Calculator, Zap, BookOpen, Trophy } from 'lucide-react';

export function Home() {
  const navigate = useNavigate();
  const { state } = useStore();

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg mt-8 gap-10">
      
      <div className="text-center space-y-4 mb-4">
        <div className="w-28 h-28 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-[2.5rem] mx-auto flex items-center justify-center shadow-[0_0_40px_rgba(34,211,238,0.4)] border border-blue-400/50">
          <Calculator className="w-14 h-14 text-white" />
        </div>
        <h1 className="text-4xl md:text-5xl font-light text-white tracking-tight mt-6">
          Math<span className="font-bold text-cyan-400">Quest</span>
        </h1>
        <p className="text-slate-400 text-lg">
          Domina los sistemas de ecuaciones jugando.
        </p>
      </div>

      {state.hearts === 0 && (
        <div className="bg-rose-500/10 text-rose-400 p-4 rounded-2xl text-center font-medium border border-rose-500/20 w-full shadow-lg">
          Te has quedado sin corazones. ¡Vuelve mañana para seguir practicando!
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 w-full relative z-10 px-4 md:px-0">
        <Button 
          size="lg" 
          variant="secondary" 
          className="h-20 text-xl md:text-2xl gap-3 w-full"
          onClick={() => navigate('/levels')}
          disabled={state.hearts === 0}
        >
          <Rocket className="w-7 h-7" /> JUGAR NIVELES
        </Button>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
          <Button 
            size="md" 
            variant="outline" 
            className="h-16 gap-3 text-sm"
            onClick={() => navigate('/practice/substitution')}
            disabled={state.hearts === 0}
          >
            <BookOpen className="w-5 h-5 text-blue-400" /> Sustitución
          </Button>

          <Button 
            size="md" 
            variant="outline" 
            className="h-16 gap-3 text-sm"
            onClick={() => navigate('/practice/equalization')}
            disabled={state.hearts === 0}
          >
            <BookOpen className="w-5 h-5 text-emerald-400" /> Igualación
          </Button>
        </div>

        <div className="grid grid-cols-1 mt-4">
          <Button 
            size="md" 
            variant="ghost" 
            className="h-16 gap-3 text-sm bg-slate-800 border-none text-yellow-400 hover:bg-slate-700 shadow-md"
            onClick={() => navigate('/achievements')}
          >
            <Trophy className="w-5 h-5" /> Tus Logros
          </Button>
        </div>
      </div>
    </div>
  );
}
