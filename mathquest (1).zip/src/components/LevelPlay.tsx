import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../lib/store';
import { Level, Equation } from '../types';
import { generateSystem, renderEquation, generateOptions } from '../lib/math';
import { playSound } from '../lib/audio';
import { Button } from './ui/Button';
import 'katex/dist/katex.min.css';
import { BlockMath } from 'react-katex';
import confetti from 'canvas-confetti';
import { CheckCircle2, XCircle, BookOpen, Lightbulb } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function LevelPlay() {
  const { playingLevel } = useParams();
  const { state, addPoints, loseHeart, levelUp, incrementExercise } = useStore();
  const [problem, setProblem] = useState<Equation | null>(null);
  
  const currentPlayLevel = (playingLevel ? parseInt(playingLevel, 10) : state.level) as Level;
  const isMaxLevel = currentPlayLevel === state.level;

  const [options, setOptions] = useState<{x: number, y: number}[]>([]);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [loadingHint, setLoadingHint] = useState(false);
  
  const [status, setStatus] = useState<'playing' | 'correct' | 'incorrect'>('playing');
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loadingExp, setLoadingExp] = useState(false);

  // Initialize problem
  useEffect(() => {
    if (!problem && status === 'playing' && state.hearts > 0) {
      const newProb = generateSystem(currentPlayLevel);
      setProblem(newProb);
      setOptions(generateOptions(newProb.solX, newProb.solY));
      setSelectedOptionIndex(null);
      setExplanation(null);
      setHint(null);
    }
  }, [currentPlayLevel, problem, status, state.hearts]);

  const handleCheck = () => {
    if (!problem || status !== 'playing' || selectedOptionIndex === null) return;

    const opt = options[selectedOptionIndex];

    if (opt.x === problem.solX && opt.y === problem.solY) {
      // Correct!
      playSound('success');
      setStatus('correct');
      addPoints(10);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#3b82f6', '#10b981', '#f59e0b']
      });
      incrementExercise(isMaxLevel);
      
      // Advance level condition
      if (isMaxLevel && state.completedExercisesInLevel >= 4 && state.level < 5) {
        setTimeout(levelUp, 1500);
      }
    } else {
      // Incorrect
      playSound('error');
      setStatus('incorrect');
      if (isMaxLevel) {
        loseHeart();
      }
    }
  };

  const getHint = async () => {
    if (!problem) return;
    setLoadingHint(true);
    try {
      const eqStr = `${renderEquation(problem.a1, problem.b1, problem.c1)}\n${renderEquation(problem.a2, problem.b2, problem.c2)}`;
      const res = await fetch('/api/math/hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problem: eqStr })
      });
      const data = await res.json();
      if (data.hint) setHint(data.hint);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingHint(false);
    }
  };

  const getExplanation = async () => {
    if (!problem) return;
    setLoadingExp(true);
    try {
      const eqStr = `${renderEquation(problem.a1, problem.b1, problem.c1)}\n${renderEquation(problem.a2, problem.b2, problem.c2)}`;
      const res = await fetch('/api/math/explain-mistake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problem: eqStr,
          method: 'cualquiera (sustitución o igualación)',
          userAnswer: selectedOptionIndex !== null ? `x = ${options[selectedOptionIndex].x}, y = ${options[selectedOptionIndex].y}` : 'Ninguna'
        })
      });
      const data = await res.json();
      if (data.explanation) {
        setExplanation(data.explanation);
      }
    } catch (e) {
      console.error(e);
      setExplanation("Lo siento, no pude cargar la explicación en este momento.");
    } finally {
      setLoadingExp(false);
    }
  };

  const handeNext = () => {
    setStatus('playing');
    setProblem(null); // will trigger useeffect
  };

  if (state.hearts === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full max-w-md mx-auto text-center mt-20">
        <XCircle className="w-24 h-24 text-rose-500 mb-6 drop-shadow-[0_0_15px_rgba(244,63,94,0.5)]" />
        <h2 className="text-3xl font-light text-white mb-3">¡Corazones <span className="font-bold text-rose-500">agotados!</span></h2>
        <p className="text-slate-400 text-lg">Has perdido todos tus corazones por hoy. Vuelve mañana para seguir practicando.</p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mt-4 flex flex-col gap-6 relative">
      <div className="flex flex-col items-center justify-center text-center space-y-2 mb-2">
        <span className="px-4 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded-full text-xs font-bold uppercase tracking-widest shadow-lg shadow-blue-500/10">
          Nivel {currentPlayLevel} {isMaxLevel ? '' : '(Práctica Libre)'}
        </span>
        <h1 className="text-3xl md:text-5xl font-light text-white tracking-tight">
          Resuelve el <span className="font-mono font-bold text-cyan-400 italic">sistema</span>
        </h1>
        {isMaxLevel && <span className="text-sm text-slate-400 font-medium mt-2">{state.completedExercisesInLevel}/5 para avanzar</span>}
      </div>

      {/* Progress Bar */}
      {isMaxLevel && (
        <div className="h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700 w-full max-w-sm mx-auto shadow-inner">
          <motion.div 
            className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.5)]"
            initial={{ width: 0 }}
            animate={{ width: `${(state.completedExercisesInLevel / 5) * 100}%` }}
            transition={{ ease: "easeInOut" }}
          />
        </div>
      )}

      <div className="bg-slate-900/80 border border-slate-700/50 rounded-[40px] p-6 md:p-12 w-full shadow-2xl relative mt-4">
        {problem ? (
          <>
            <div className="text-3xl md:text-4xl w-full flex justify-center py-8 bg-slate-800/40 rounded-3xl mb-8 border border-slate-700/50 shadow-inner text-white overflow-x-auto custom-scroll">
              <BlockMath>
                {`\\begin{cases} 
                  ${renderEquation(problem.a1, problem.b1, problem.c1)} \\\\ 
                  ${renderEquation(problem.a2, problem.b2, problem.c2)} 
                \\end{cases}`}
              </BlockMath>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-lg mx-auto mb-2">
              {options.map((opt, i) => {
                const isSelected = selectedOptionIndex === i;
                const isStatusCorrect = status === 'correct' && isSelected;
                const isStatusError = status === 'incorrect' && isSelected;
                const isActualCorrect = opt.x === problem.solX && opt.y === problem.solY;
                
                let btnClasses = "relative w-full rounded-2xl py-4 px-4 text-2xl font-mono text-center transition-all cursor-pointer border-2 ";
                if (status !== 'playing') {
                   // if correct and this is selected
                   if (isStatusCorrect) btnClasses += "bg-emerald-500/20 border-emerald-400 text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.2)]";
                   else if (isStatusError) btnClasses += "bg-rose-500/20 border-rose-400 text-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.2)]";
                   else if (isActualCorrect) btnClasses += "bg-emerald-500/10 border-emerald-400/50 text-emerald-400/50"; // reveal correct if failed
                   else btnClasses += "bg-slate-800/30 border-slate-700/50 text-slate-600";
                } else {
                   if (isSelected) btnClasses += "bg-cyan-900/40 border-cyan-400 text-white shadow-[0_0_15px_rgba(34,211,238,0.2)] scale-105 z-10";
                   else btnClasses += "bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700 hover:border-slate-500";
                }

                return (
                  <div 
                    key={i} 
                    className={btnClasses}
                    onClick={() => status === 'playing' && setSelectedOptionIndex(i)}
                  >
                     x = {opt.x}, y = {opt.y}
                  </div>
                );
              })}
            </div>

            {status === 'playing' && hint && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-purple-900/30 border border-purple-500/30 rounded-2xl p-5 text-purple-200 text-sm mt-6 w-full max-w-lg mx-auto flex items-start gap-4 shadow-xl">
                <div className="p-2 bg-purple-500/20 rounded-xl shrink-0"><Lightbulb className="w-5 h-5 text-purple-400" /></div>
                <p className="leading-relaxed font-medium">{hint}</p>
              </motion.div>
            )}
          </>
        ) : (
          <div className="animate-pulse flex flex-col items-center gap-6 w-full py-8">
            <div className="h-24 bg-slate-800/50 rounded-3xl w-full max-w-sm"></div>
            <div className="flex gap-6 w-full justify-center">
              <div className="h-16 bg-slate-800/50 rounded-2xl w-40"></div>
              <div className="h-16 bg-slate-800/50 rounded-2xl w-40"></div>
            </div>
          </div>
        )}
      </div>

      <div className="min-h-[6rem] mt-4 relative flex justify-center w-full">
        <AnimatePresence mode="wait">
          {status === 'playing' ? (
            <motion.div key="checkBtn" initial={{y: 20, opacity: 0}} animate={{y: 0, opacity: 1}} exit={{y: 20, opacity: 0}} className="w-full max-w-sm flex flex-col items-center gap-4">
              <Button 
                onClick={handleCheck} 
                fullWidth={true}
                size="lg" 
                variant={selectedOptionIndex === null ? 'outline' : 'secondary'}
                disabled={selectedOptionIndex === null}
                className="px-12 w-full active:translate-y-2"
              >
                ¡COMPROBAR!
              </Button>
              <button 
                onClick={getHint} 
                disabled={loadingHint || !!hint}
                className="text-purple-400 hover:text-purple-300 text-sm font-bold flex items-center gap-2 transition-colors disabled:opacity-50 mt-2"
              >
                <Lightbulb className="w-4 h-4" /> {loadingHint ? 'Pensando...' : (hint ? 'Revisa la pista arriba' : 'Dame una pista paso a paso')}
              </button>
            </motion.div>
          ) : status === 'correct' ? (
             <motion.div key="success" initial={{scale: 0.9, opacity: 0}} animate={{scale: 1, opacity: 1}} className="w-full flex flex-col md:flex-row gap-4 items-center justify-center mt-2">
                <div className="w-full md:w-auto bg-green-500/20 border border-green-500/50 text-green-400 shadow-[0_0_20px_rgba(34,197,94,0.2)] rounded-2xl flex items-center justify-center px-8 py-4 font-bold gap-3 text-lg">
                  <CheckCircle2 className="w-7 h-7" /> ¡Excelente!
                </div>
                <Button onClick={handeNext} variant="primary" size="lg" className="w-full md:w-auto px-10 border border-blue-400/50 shadow-[0_0_20px_rgba(59,130,246,0.2)]">
                  Siguiente 
                </Button>
             </motion.div>
          ) : (
            <motion.div key="error" initial={{scale: 0.9, opacity: 0}} animate={{scale: 1, opacity: 1}} className="w-full flex flex-col gap-5 mt-2">
                <div className="w-full flex flex-col md:flex-row items-center justify-center gap-4">
                  <div className="w-full md:w-auto bg-rose-500/20 border border-rose-500/50 text-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.2)] rounded-2xl flex items-center justify-center px-8 py-4 font-bold gap-3 text-lg">
                    <XCircle className="w-7 h-7" /> Casi lo logras
                  </div>
                  <Button onClick={getExplanation} variant="outline" size="lg" disabled={loadingExp} className="w-full md:w-auto px-8">
                    {loadingExp ? 'Cargando...' : 'Ver Explicación'}
                  </Button>
                  <Button onClick={handeNext} variant="primary" size="lg" className="w-full md:w-auto px-10">
                    Omitir
                  </Button>
                </div>
                
                {explanation && (
                   <motion.div initial={{opacity: 0, height: 0}} animate={{opacity: 1, height: 'auto'}} className="bg-slate-800/80 p-8 rounded-3xl text-slate-200 border border-slate-700 text-left shadow-2xl">
                     <h4 className="font-bold mb-4 text-cyan-400 text-sm tracking-widest uppercase flex items-center gap-2"><BookOpen className="w-4 h-4"/> Explicación paso a paso:</h4>
                     <div className="prose prose-sm md:prose-base prose-invert max-w-none whitespace-pre-wrap">
                        {explanation}
                     </div>
                   </motion.div>
                )}
             </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
