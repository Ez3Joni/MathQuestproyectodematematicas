import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../lib/store';
import { motion, AnimatePresence } from 'motion/react';
import { Lock, Unlock, Play, ChevronRight, Check, Target } from 'lucide-react';
import { Button } from './ui/Button';
import { Level } from '../types';

const LEVEL_INFO = {
  1: { title: "Sustitución Básica", desc: "Aprende las bases del método de sustitución con ecuaciones simples.", diff: "Fácil", color: "from-blue-400 to-blue-600" },
  2: { title: "Igualación Básica", desc: "Introduce el método de igualación con variables despejadas.", diff: "Fácil", color: "from-emerald-400 to-emerald-600" },
  3: { title: "Sistemas Mixtos", desc: "Combina ambos métodos en sistemas que requieren manipulación previa.", diff: "Media", color: "from-amber-400 to-orange-500" },
  4: { title: "Números Negativos", desc: "Cuidado con los signos. Sistemas con coeficientes y resultados negativos.", diff: "Difícil", color: "from-rose-400 to-rose-600" },
  5: { title: "Maestro de Sistemas", desc: "El desafío definitivo. Sistemas más complejos que pondrán a prueba todo lo aprendido.", diff: "Experto", color: "from-purple-500 to-indigo-600" },
};

export function LevelSelector() {
  const navigate = useNavigate();
  const { state } = useStore();
  const maxLevel = state.level;
  
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);

  const handleLevelClick = (levelNumber: number) => {
    if (levelNumber <= maxLevel) {
      if (selectedLevel === levelNumber) {
        setSelectedLevel(null);
      } else {
        setSelectedLevel(levelNumber);
      }
    }
  };

  return (
    <div className="w-full max-w-3xl flex flex-col items-center">
      <div className="text-center mb-8">
        <h2 className="text-3xl md:text-5xl font-light text-white tracking-tight">
          Selección de <span className="font-bold text-blue-400">Nivel</span>
        </h2>
        <p className="text-slate-400 mt-3 text-lg">
          Elige un nivel para practicar y mejorar tus habilidades
        </p>
      </div>

      <div className="flex flex-col gap-4 w-full">
        {[1, 2, 3, 4, 5].map((levelNumber) => {
          const isUnlocked = levelNumber <= maxLevel;
          const isCompleted = levelNumber < maxLevel;
          const info = LEVEL_INFO[levelNumber as Level];
          const isSelected = selectedLevel === levelNumber;

          return (
            <div key={levelNumber} className="w-full relative">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: levelNumber * 0.1 }}
                className={`w-full rounded-3xl border-2 transition-all cursor-pointer overflow-hidden ${
                  isUnlocked
                    ? isSelected 
                      ? 'border-blue-500/50 bg-slate-800/80 shadow-[0_0_20px_rgba(59,130,246,0.2)]'
                      : 'border-slate-700 bg-slate-800/50 hover:bg-slate-800'
                    : 'border-slate-800 bg-slate-900/50 opacity-70'
                }`}
                onClick={() => handleLevelClick(levelNumber)}
              >
                <div className="p-4 md:p-6 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                      isUnlocked 
                        ? isCompleted
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : `bg-gradient-to-br ${info.color} text-white`
                        : 'bg-slate-800 text-slate-500'
                    }`}>
                      {isUnlocked && isCompleted ? <Check className="w-6 h-6" /> : isUnlocked ? <span className="text-xl font-bold">{levelNumber}</span> : <Lock className="w-6 h-6" />}
                    </div>
                    
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Nivel {levelNumber}</span>
                        {isUnlocked && <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-700 text-slate-300`}>{info.diff}</span>}
                      </div>
                      <h3 className={`text-xl font-bold ${isUnlocked ? 'text-white' : 'text-slate-500'}`}>
                        {isUnlocked ? info.title : 'Nivel Bloqueado'}
                      </h3>
                      {isUnlocked && isCompleted && <span className="text-sm text-emerald-400 font-medium mt-1">✔ Completado (Práctica sin perder ❤️)</span>}
                    </div>
                  </div>
                  
                  {isUnlocked && (
                    <motion.div
                      animate={{ rotate: isSelected ? 90 : 0 }}
                      className="text-slate-400"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </motion.div>
                  )}
                </div>

                <AnimatePresence>
                  {isSelected && isUnlocked && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t border-slate-700/50 overflow-hidden"
                    >
                      <div className="p-4 md:p-6 bg-slate-800/50 flex flex-col md:flex-row items-center gap-6">
                        <div className="flex-1">
                          <p className="text-slate-300 mb-4">{info.desc}</p>
                          <div className="flex items-center gap-4 text-sm text-slate-400">
                            <span className="flex items-center gap-1"><Target className="w-4 h-4" /> 5 Ejercicios para avanzar</span>
                          </div>
                        </div>
                        <Button
                          variant="primary"
                          className="w-full md:w-auto shrink-0 shadow-[0_0_15px_rgba(59,130,246,0.3)]"
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/play/${levelNumber}`);
                          }}
                        >
                          {isCompleted ? 'Practicar Nivel' : 'Jugar Nivel'} <Play className="w-4 h-4 ml-2" />
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
