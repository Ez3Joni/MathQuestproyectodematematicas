import { Equation, Level } from '../types';

// Helper to generate a random integer in [min, max]
export function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Generate a system of equations with a guaranteed nice solution
export function generateSystem(level: Level, forceMethod?: 'substitution' | 'equalization'): Equation {
  let solX = 0;
  let solY = 0;
  let a1=1, b1=1, a2=1, b2=1;

  switch (level) {
    case 1:
      // Level 1: Easy Substitution. Usually one variable is already isolated or has coeff 1. Positive numbers mostly.
      solX = randomInt(1, 5);
      solY = randomInt(1, 5);
      // Eq1: y = a1*x + c1' => -a1*x + 1*y = c1
      a1 = randomInt(-3, -1); // e.g. -2x
      b1 = 1;
      a2 = randomInt(1, 4);
      b2 = randomInt(1, 4);
      break;
    case 2:
      // Level 2: Easy Equalization. Both equations might have a variable easy to isolate, or same coeff.
      solX = randomInt(1, 6);
      solY = randomInt(1, 6);
      // y = a*x + b, y = c*x + d => -ax + y = b, -cx + y = d
      a1 = randomInt(-4, 4) || 1;
      b1 = 1;
      a2 = randomInt(-4, 4) || 2;
      b2 = 1;
      if (a1 === a2) a2 += 1;
      break;
    case 3:
      // Level 3: Mixed. Might need a bit of work.
      solX = randomInt(1, 8);
      solY = randomInt(1, 8);
      a1 = randomInt(1, 4);
      b1 = randomInt(-3, 3) || 1;
      a2 = randomInt(1, 4);
      b2 = randomInt(-3, 3) || 2;
      break;
    case 4:
      // Level 4: Negative numbers.
      solX = randomInt(-5, 5);
      solY = randomInt(-5, 5);
      a1 = randomInt(-5, -1);
      b1 = randomInt(-5, 5) || 1;
      a2 = randomInt(-5, 5) || -1;
      b2 = randomInt(-5, -1);
      break;
    case 5:
      // Level 5: Harder, maybe larger numbers or they need to multiply both equations to cancel if they use elimination (but we focus on sub/eq)
      solX = randomInt(-10, 10);
      solY = randomInt(-10, 10);
      a1 = randomInt(-6, 6) || 1;
      b1 = randomInt(-6, 6) || 1;
      a2 = randomInt(-6, 6) || -1;
      b2 = randomInt(-6, 6) || -1;
      break;
  }

  // Calculate the constants based on the chosen solution
  const c1 = a1 * solX + b1 * solY;
  const c2 = a2 * solX + b2 * solY;

  return {
    id: Math.random().toString(36).substring(7),
    a1, b1, c1,
    a2, b2, c2,
    solX, solY
  };
}

export function formatTerm(coeff: number, variable: string, isFirst: boolean): string {
  if (coeff === 0) return '';
  
  let result = '';
  if (coeff < 0) {
    result += isFirst ? '-' : ' - ';
  } else if (!isFirst) {
    result += ' + ';
  }

  const absCoeff = Math.abs(coeff);
  if (absCoeff === 1) {
    result += variable;
  } else {
    result += absCoeff + variable;
  }

  return result;
}

export function renderEquation(a: number, b: number, c: number): string {
  let eq = '';
  eq += formatTerm(a, 'x', true);
  if (eq === '') {
    eq += formatTerm(b, 'y', true);
  } else {
    eq += formatTerm(b, 'y', false);
  }
  
  return eq + ' = ' + c;
}

export function generateOptions(solX: number, solY: number): {x: number, y: number}[] {
  const ops: {x: number, y: number}[] = [{x: solX, y: solY}];
  const addUnique = (x: number, y: number) => {
    if (!ops.some(o => o.x === x && o.y === y)) {
      ops.push({x, y});
    }
  };

  addUnique(solY, solX);
  addUnique(-solX, solY);
  addUnique(solX, -solY);
  addUnique(-solX, -solY);
  addUnique(solX + 1, solY);
  addUnique(solX, solY - 1);
  addUnique(solX + 2, solY + 1);

  const options = ops.slice(0, 4);
  for (let i = options.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [options[i], options[j]] = [options[j], options[i]];
  }
  return options;
}
