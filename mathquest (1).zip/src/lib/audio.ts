let audioCtx: AudioContext | null = null;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playSound(type: 'click' | 'success' | 'error') {
  try {
    const ctx = getAudioContext();
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'click') {
      // Short, subtle click
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, t);
      osc.frequency.exponentialRampToValueAtTime(200, t + 0.1);
      
      gain.gain.setValueAtTime(0.05, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      
      osc.start(t);
      osc.stop(t + 0.1);
    } else if (type === 'success') {
      // Ascending arpeggio (C5 -> E5 -> G5 -> C6)
      osc.type = 'triangle';
      
      osc.frequency.setValueAtTime(523.25, t); // C5
      osc.frequency.setValueAtTime(659.25, t + 0.1); // E5
      osc.frequency.setValueAtTime(783.99, t + 0.2); // G5
      osc.frequency.setValueAtTime(1046.50, t + 0.3); // C6

      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.1, t + 0.05);
      gain.gain.setValueAtTime(0.1, t + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
      
      osc.start(t);
      osc.stop(t + 0.5);
    } else if (type === 'error') {
      // Low descending buzz
      osc.type = 'sawtooth';
      
      osc.frequency.setValueAtTime(300, t);
      osc.frequency.exponentialRampToValueAtTime(100, t + 0.4);
      
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.1, t + 0.05);
      gain.gain.setValueAtTime(0.1, t + 0.2);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
      
      osc.start(t);
      osc.stop(t + 0.4);
    }
  } catch (e) {
    console.warn('Audio play failed', e);
  }
}

let ambientOsc1: OscillatorNode | null = null;
let ambientOsc2: OscillatorNode | null = null;
let ambientGain: GainNode | null = null;

export function playAmbientMusic() {
  try {
    const ctx = getAudioContext();
    if (ambientGain) return; // Already playing

    ambientGain = ctx.createGain();
    ambientGain.connect(ctx.destination);
    
    const t = ctx.currentTime;
    ambientGain.gain.setValueAtTime(0, t);
    ambientGain.gain.linearRampToValueAtTime(0.015, t + 4); // Very soft

    ambientOsc1 = ctx.createOscillator();
    ambientOsc1.type = 'sine';
    ambientOsc1.frequency.value = 110; // A2
    ambientOsc1.connect(ambientGain);
    ambientOsc1.start();

    ambientOsc2 = ctx.createOscillator();
    ambientOsc2.type = 'triangle';
    ambientOsc2.frequency.setValueAtTime(110.5, t); // Slight detuning
    ambientOsc2.connect(ambientGain);
    ambientOsc2.start();

  } catch (e) {
    console.warn('Ambient music play failed', e);
  }
}

export function stopAmbientMusic() {
  if (ambientGain && audioCtx) {
    const t = audioCtx.currentTime;
    ambientGain.gain.linearRampToValueAtTime(0, t + 2);
    setTimeout(() => {
      ambientOsc1?.stop();
      ambientOsc2?.stop();
      ambientGain?.disconnect();
      ambientOsc1 = null;
      ambientOsc2 = null;
      ambientGain = null;
    }, 2000);
  }
}
