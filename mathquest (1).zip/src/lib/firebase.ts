import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut as fbSignOut } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer, setDoc, updateDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { UserState } from '../types';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export async function loginWithGoogle() {
  try {
    await signInWithPopup(auth, googleProvider);
  } catch (error) {
    console.error('Login failed', error);
  }
}

export async function logoutUser() {
  await fbSignOut(auth);
}

export async function loadUserData(userId: string): Promise<UserState | null> {
  try {
    const docRef = doc(db, 'users', userId);
    const snap = await getDocFromServer(docRef);
    if (snap.exists()) {
      return snap.data() as UserState;
    }
    return null;
  } catch (error: any) {
    console.warn('Failed to load user data', error);
    return null;
  }
}

export async function saveUserData(userId: string, state: UserState, isNew: boolean = false) {
  try {
    const docRef = doc(db, 'users', userId);
    if (isNew) {
      await setDoc(docRef, state);
    } else {
      await updateDoc(docRef, state as any);
    }
  } catch (error: any) {
    console.warn('Failed to save user data', error);
  }
}
