import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { UserState } from '../types';
import { checkAchievements } from './achievements';
import { auth, loadUserData, saveUserData, loginWithGoogle, logoutUser } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

interface StoreContextType {
  state: UserState;
  recentUnlocks: string[];
  user: User | null;
  loadingAuth: boolean;
  addPoints: (pts: number) => void;
  loseHeart: () => void;
  levelUp: () => void;
  incrementExercise: (isMaxLevel?: boolean) => void;
  resetProgress: () => void;
  clearRecentUnlocks: () => void;
  login: () => void;
  logout: () => void;
}

const defaultState: UserState = {
  hearts: 5,
  lastHeartReset: new Date().setHours(0,0,0,0),
  points: 0,
  level: 1,
  completedExercisesInLevel: 0,
  unlockedAchievements: [],
  totalCorrectAnswers: 0,
  totalDaysPlayed: 0,
  lastActiveDay: null,
};

const StoreContext = createContext<StoreContextType | null>(null);

export const StoreProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);
  const dataLoadedRef = useRef(false);

  const [state, setState] = useState<UserState>(() => {
    const saved = localStorage.getItem('mathquest-state');
    let parsed = defaultState;
    if (saved) {
      try {
        parsed = { ...defaultState, ...JSON.parse(saved) };
      } catch (e) {
        parsed = defaultState;
      }
    }
    
    // Day logic
    const todayStr = new Date().setHours(0,0,0,0);
    if (parsed.lastHeartReset !== todayStr) {
      parsed.hearts = 5;
      parsed.lastHeartReset = todayStr;
    }
    if (parsed.lastActiveDay !== todayStr) {
      parsed.totalDaysPlayed += 1;
      parsed.lastActiveDay = todayStr;
    }
    return parsed;
  });

  const [recentUnlocks, setRecentUnlocks] = useState<string[]>([]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      
      if (u) {
        const remoteData = await loadUserData(u.uid);
        if (remoteData) {
           // Day logic for remote
           const todayStr = new Date().setHours(0,0,0,0);
           const needsUpdate = remoteData.lastHeartReset !== todayStr || remoteData.lastActiveDay !== todayStr;
           
           if (remoteData.lastHeartReset !== todayStr) {
             remoteData.hearts = 5;
             remoteData.lastHeartReset = todayStr;
           }
           if (remoteData.lastActiveDay !== todayStr) {
             remoteData.totalDaysPlayed = (remoteData.totalDaysPlayed || 0) + 1;
             remoteData.lastActiveDay = todayStr;
           }
           
           setState(remoteData);
           if (needsUpdate) {
              await saveUserData(u.uid, remoteData, false);
           }
        } else {
           // New user, save local to DB
           await saveUserData(u.uid, state, true);
        }
      } else {
        // Logged out, maybe revert to local logic, but let's just keep whatever is in state.
      }
      dataLoadedRef.current = true;
      setLoadingAuth(false);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    // Only save if data has been initially resolved to avoid overwriting remote with default local
    if (!dataLoadedRef.current) return;
    
    localStorage.setItem('mathquest-state', JSON.stringify(state));
    if (user) {
      saveUserData(user.uid, state, false).catch(() => {});
    }

    // Check achievements
    const newUnlocks = checkAchievements(state);
    if (newUnlocks.length > 0) {
      setState(s => ({
        ...s,
        unlockedAchievements: [...(s.unlockedAchievements || []), ...newUnlocks]
      }));
      setRecentUnlocks(prev => [...prev, ...newUnlocks]);
    }
  }, [state, user]);

  const addPoints = (pts: number) => setState(s => ({ ...s, points: s.points + pts }));
  
  const loseHeart = () => setState(s => ({ ...s, hearts: Math.max(0, s.hearts - 1) }));
  
  const levelUp = () => setState(s => {
    if (s.level < 5) return { ...s, level: (s.level + 1) as any, completedExercisesInLevel: 0 };
    return s;
  });

  const incrementExercise = (isMaxLevel: boolean = true) => setState(s => ({ 
    ...s, 
    completedExercisesInLevel: isMaxLevel ? s.completedExercisesInLevel + 1 : s.completedExercisesInLevel,
    totalCorrectAnswers: (s.totalCorrectAnswers || 0) + 1
  }));

  const resetProgress = () => {
    setState({ ...defaultState, lastHeartReset: new Date().setHours(0,0,0,0), lastActiveDay: new Date().setHours(0,0,0,0), totalDaysPlayed: 1 });
  };

  const clearRecentUnlocks = () => setRecentUnlocks([]);

  return (
    <StoreContext.Provider value={{ 
      state, recentUnlocks, user, loadingAuth,
      addPoints, loseHeart, levelUp, incrementExercise, resetProgress, clearRecentUnlocks,
      login: loginWithGoogle, logout: logoutUser 
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};
