import { Achievement, UserState } from '../types';

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first_win', title: 'Primer Paso', description: 'Resuelve tu primer sistema de ecuaciones correctamente.', icon: 'CheckCircle' },
  { id: 'level_2', title: 'Avanzando', description: 'Alcanza el Nivel 2.', icon: 'ArrowUpCircle' },
  { id: 'level_5', title: 'Maestro de Ecuaciones', description: 'Alcanza el Nivel 5.', icon: 'Award' },
  { id: 'points_100', title: 'Cien Puntos', description: 'Acumula 100 puntos de XP.', icon: 'Star' },
  { id: 'points_500', title: 'Medio Millar', description: 'Acumula 500 puntos de XP.', icon: 'Star' },
  { id: 'days_3', title: 'Estudiante Constante', description: 'Juega durante 3 días distintos.', icon: 'Calendar' },
  { id: 'answers_10', title: 'Diez Aciertos', description: 'Resuelve 10 ejercicios correctamente.', icon: 'Target' }
];

// Returns an array of newly unlocked achievement IDs based on the current state
export function checkAchievements(state: UserState): string[] {
  const newUnlocks: string[] = [];
  const { unlockedAchievements, points, level, totalDaysPlayed, totalCorrectAnswers } = state;

  const checkAndAdd = (id: string, condition: boolean) => {
    if (condition && !unlockedAchievements.includes(id)) {
      newUnlocks.push(id);
    }
  };

  checkAndAdd('first_win', totalCorrectAnswers >= 1);
  checkAndAdd('answers_10', totalCorrectAnswers >= 10);
  checkAndAdd('level_2', level >= 2);
  checkAndAdd('level_5', level >= 5);
  checkAndAdd('points_100', points >= 100);
  checkAndAdd('points_500', points >= 500);
  checkAndAdd('days_3', totalDaysPlayed >= 3);

  return newUnlocks;
}
