export type Level = 1 | 2 | 3 | 4 | 5;

export interface Equation {
  id: string; // for internal use
  a1: number;
  b1: number;
  c1: number;
  a2: number;
  b2: number;
  c2: number;
  solX: number;
  solY: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string; // Name of Lucide icon
}

export interface UserState {
  hearts: number;
  lastHeartReset: number; // timestamp (day)
  points: number;
  level: Level;
  completedExercisesInLevel: number;
  
  // Track for achievements
  unlockedAchievements: string[];
  totalCorrectAnswers: number;
  totalDaysPlayed: number;
  lastActiveDay: number | null;
}
