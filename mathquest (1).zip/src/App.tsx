/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { StoreProvider } from './lib/store';
import { Layout } from './components/Layout';
import { Home } from './components/Home';
import { LevelPlay } from './components/LevelPlay';
import { MethodPractice } from './components/MethodPractice';
import { Achievements } from './components/Achievements';
import { LevelSelector } from './components/LevelSelector';

export default function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="levels" element={<LevelSelector />} />
            <Route path="play" element={<LevelPlay />} />
            <Route path="play/:playingLevel" element={<LevelPlay />} />
            <Route path="practice/:method" element={<MethodPractice />} />
            <Route path="achievements" element={<Achievements />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </StoreProvider>
  );
}
